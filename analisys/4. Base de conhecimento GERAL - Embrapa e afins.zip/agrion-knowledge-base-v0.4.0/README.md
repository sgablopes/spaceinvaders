# Agrion · Base de conhecimento agronômico

**Versão 0.1.0 · 14 de novembro de 2026 · Entrega parcial auditada documentalmente**

Esta edição permite recuperar sequências agrícolas, consultar resultados nas condições em que foram obtidos e chegar à página ou tabela de origem. Abrange as 17 culturas do projeto e 27 auxiliares. A curadoria priorizou sequências, calendários e comparações verificáveis no texto integral.

| Conteúdo | Quantidade |
|---|---:|
| Publicações catalogadas | 86 |
| Publicações com extração de seções do texto integral | 41 |
| Publicações na fila de leitura | 45 |
| Fichas de taxonomia / fichas fitossanitárias EPPO | 44 / 17 |
| Achados agronômicos com origem e condições | 215 |
| Registros de calendário / sequências | 39 / 55 |
| Registros fitossanitários / registros de solo | 35 / 16 |

O relatório de cobertura apresenta as 102 combinações entre culturas principais e temas. A aba **Fila de leitura** identifica os documentos sem extração. O **manifesto.json** registra o que foi processado, os limites e as pendências por cultura.

## Importação

Use o nome de cada CSV como nome de tabela, a codificação UTF-8, cabeçalho na primeira linha e vírgula como separador. Preserve IDs como texto. Importe campos vazios como nulos e use ponto como separador decimal. Os arquivos **fonte_culturas** e **evidencia_culturas** resolvem relações muitos-para-muitos.

| Para investigar | Tabelas | Campos importantes |
|---|---|---|
| Qual espécie, uso e material? | culturas, fontes | fonte_taxonomia_id, fonte_uso_id, recorte e grupo |
| Que literatura existe? | fontes, fonte_culturas | tipo_fonte, temas_indexados, estado_leitura e direitos_uso |
| Quando plantar ou colher? | calendarios, evidencias | evento, marcos, material, região e precisão da janela |
| Que espécie precede outra? | rotacoes, evidencias | antecessora, consorte, cobertura intercalar, sucessora e estudo_id |
| Qual foi o efeito e em qual solo? | manejo_solo, evidencias | desfecho, métrica, unidade, solo, regime hídrico e comparador |
| Que organismo está documentado? | pragas_doencas, evidencias | tipo_registro, categoria_hospedeiro, sintomas e âmbito da distribuição |

## Consulta de exemplo

Após a importação no SQLite, a consulta abaixo recupera as sequências de feijão no Brasil e as medições ligadas a elas. A junção opcional conserva uma sequência mesmo quando a fonte oferece somente uma orientação qualitativa.

~~~sql
SELECT anterior.nome_pt AS antecessora, seguinte.nome_pt AS sucessora,
       e.regiao, e.solo, e.condicoes, e.limitacoes,
       y.metrica, y.valor, y.unidade, y.comparador,
       f.titulo, f.url_original, e.localizador, y.localizador AS localizador_medicao
FROM rotacoes AS r
JOIN culturas AS anterior ON anterior.cultura_id = r.antecessora_id
JOIN culturas AS seguinte ON seguinte.cultura_id = r.sucessora_id
JOIN evidencias AS e ON e.evidencia_id = r.evidencia_id
JOIN fontes AS f ON f.fonte_id = e.fonte_id
LEFT JOIN evidencias AS y
  ON y.rotacao_id = r.rotacao_id AND y.cultura_desfecho_id = r.sucessora_id
WHERE r.sucessora_id = 'feijao' AND e.pais_iso2 = 'BR'
  AND e.status_validacao = 'conferida_na_fonte';
~~~

Para Santo Antônio de Goiás, a consulta retorna feijão após crotalária-júncea e após sorgo forrageiro. Os rendimentos de 1.722 e 1.760 kg/ha pertencem ao mesmo ensaio. A comparação entre as coberturas não foi estatisticamente significativa. O contraste de aproximadamente 40% descrito pelos autores é entre plantio direto e preparo convencional. Fonte EMB-890976, figura 3 e discussão. [Artigo original](https://www.alice.cnptia.embrapa.br/alice/handle/doc/890976)

## Como interpretar a evidência

1. Filtre a cultura do desfecho antes de agregar produtividade. Grãos, açúcar, colmos, raízes frescas e algodão em caroço são grandezas distintas. Uma cultura pode participar de um ensaio apenas como antecessora.
2. Recupere safra, cultivar, água, região, solo e comparador. Campo vazio significa dado ausente ou inaplicável. A granularidade geográfica segue a fonte. A correspondência entre região e propriedade e a integração com GAEZ, NASA POWER e AquaCrop são posteriores.
3. Agrupe tratamentos do mesmo ensaio usando estudo_id. Um ensaio pode gerar várias linhas. Uma obra secundária pode reproduzir um estudo anterior. O número de registros mede volume de dados, e o número de estudos independentes requer conferência das origens.
4. Preserve a precisão da fonte. “Meados de março” não determina um dia exato. Janeiro–maio no ensaio de tef em Koga descreve a campanha da pesquisa. Para uso operacional de calendários brasileiros, confira safra, município e zoneamento vigente.
5. “Host” e “Experimental” são categorias diferentes na EPPO. Uma distribuição nacional é atributo do organismo. Diagnóstico de infestação em um talhão requer dados locais. Para uma auxiliar, o cadastro não estabelece calibração de um modelo AquaCrop.

## Pesquisa, revisão e atualização

A descoberta partiu de Embrapa Alice, Infoteca-e e Portal Embrapa, com buscas por cultura, nome científico, finalidade e tema. Registros AGRIS direcionaram a artigos originais e a repositórios institucionais. As fontes incluem fichas Plantwise, registros EPPO e referências GBIF para identificação taxonômica de auxiliares.

Alice e Infoteca-e documentam o protocolo OAI-PMH. A operação Identify respondeu nos dois repositórios. A coleta desta versão combinou busca focalizada, leitura de metadados DC/citation, resolução de handles e consulta dos textos. Para ampliar a enumeração, ListRecords admite metadataPrefix=oai_dc e continuação via resumptionToken. Metadados colhidos pelo protocolo precisam ser vinculados ao arquivo integral antes da extração. [Interoperabilidade Alice](https://www.alice.cnptia.embrapa.br/alice/interoperabilidade.jsp?locale=pt_BR) · [Interoperabilidade Infoteca-e](https://www.infoteca.cnptia.embrapa.br/infoteca/interoperabilidade.jsp?locale=pt_BR)

Ao incluir obras, confira DOI, handle, título normalizado, autores e ano. Um espelho AGRIS, uma versão linguística da interface e uma cópia PDF podem remeter ao mesmo estudo. Edições diferentes de um manual podem coexistir. Preserve os IDs já publicados e registre no manifesto fontes e registros afetados.

A auditoria incluiu conferência documental e integridade relacional. Transferibilidade regional e revisão agronômica independente continuam pendentes. A planilha documenta inconsistências específicas, como a legenda da tabela 3 de mandioca em Paranavaí e uma média da tabela de germinação da quinoa.

## Direitos

O pacote contém referências, fatos estruturados e sínteses próprias. Cada fonte tem um campo de direitos. O rodapé dos repositórios Embrapa indica CC BY-NC-ND 4.0; artigos específicos podem ter licença própria. O rodapé das fichas Plantwise informa as condições de uso. A EPPO reserva direitos sobre seu conteúdo. Para republicar documentos, imagens, traduções ou listas extensas, conferir a fonte específica. Os PDFs originais não integram a distribuição.


## Versão 0.2.0 (parcial)

Veja `manifesto.json`, `relatorio_comparativo_v0.1_v0.2.xlsx`, `historico_v0.1_v0.2.csv` e `auditoria_integridade.json`. Nove publicações pendentes foram analisadas; 36 permanecem na fila. A revisão agronômica especializada ainda é necessária.


## v0.3.0 — entrega parcial

Execute `python auditoria_v0.3.py` para verificar integridade. Consulte os relatórios JSON de comparação, cobertura, qualidade e seis casos de uso. A fila científica continua no manifesto; resultados condicionados exigem avaliação agronômica local.


## v0.4.0

Integração controlada do lote de 12 fontes. Consulte `auditoria_individual_15.csv`, `comparativo_v0.3_v0.4.json` e `auditoria_integridade_v0.4.json`. Duas evidências redundantes e seus registros dependentes estão em `quarentena/`. Fontes parcialmente analisadas não foram declaradas concluídas.
