# Dicionário de dados

Versão 0.1.0. CSV UTF-8, vírgula entre campos, aspas duplas para escape e ponto decimal. Cabeçalho na primeira linha. Campo vazio significa desconhecido, não estruturado ou inaplicável. Zero é um valor observado. Os IDs são texto opaco; preservar os valores existentes em novas edições.

## Tipos de evidência

| Valor | Uso |
|---|---|
| resultado_experimental | Medição ou tratamento observado em experimento de campo ou laboratório. |
| resultado_experimental_secundario | Resultado de ensaio reproduzido ou descrito em obra posterior. |
| recomendacao_tecnica | Orientação técnica em guia, circular ou ficha de extensão. |
| resultado_modelo | Resultado de simulação sob premissas regionais ou de solo específicas. |
| associacao_documentada | Relação biológica ou agrícola documentada sem teste causal do efeito. |
| observacao_de_levantamento | Ocorrência ou padrão registrado em levantamento. |
| caracterizacao_publicada | Descritor publicado de material, uso ou prática. |
| hipotese_inferencia | Classe reservada para hipóteses; sem achados aceitos nesta versão. |
| informacao_insuficiente | A insuficiência é registrada no manifesto e na fila. Resumos sem conferência do original não geram achados. |

## culturas.csv

Uma linha por recorte agrícola, incluindo identificações apenas até gênero.

| Campo | Definição |
|---|---|
| cultura_id | ID estável do recorte agrícola. Chave primária em culturas e estrangeira nas demais tabelas. |
| nome_pt | Denominação principal em português. |
| nomes_en | Variantes de busca em inglês, separadas por barra vertical. |
| nome_cientifico | Táxon adotado, em nível de espécie, grupo infraespecífico ou gênero. |
| familia | Família botânica informada na ficha taxonômica. |
| sinonimos_cientificos | Seleção de sinônimos científicos da referência, separada por barra vertical. Ausência não significa inexistência. |
| grupo | escopo_aquacrop ou auxiliar, conforme o escopo do projeto. |
| finalidade | Etiqueta do uso agrícola empregada para indexação. |
| fonte_taxonomia_id | Chave estrangeira da ficha taxonômica em fontes. |
| recorte | Delimitação do tipo comercial ou grupo biológico coberto. |
| localizador_taxonomia | Parte da ficha usada para identificar o táxon. |
| status_taxonomia | Estado de conferência documental da identificação. |
| nomes_pt_alternativos | Vocabulário de busca em português, incluindo denominações regionais. |
| fonte_uso_id | Chave estrangeira da publicação correspondente ao uso da cultura no sistema. |

## fontes.csv

Uma obra ou ficha por linha.

| Campo | Definição |
|---|---|
| fonte_id | ID persistente da referência; chave primária em fontes e estrangeira nas demais tabelas. |
| titulo | Título da publicação ou da ficha. |
| autores | Crédito bibliográfico pessoal ou institucional; separadores podem refletir a fonte. |
| papel_credito | Autor, contribuinte do catálogo ou instituição responsável. |
| ano | Ano de publicação ou revisão catalogada. Nulo para ficha dinâmica sem ano bibliográfico. |
| doi | DOI sem prefixo de URL, quando confirmado. |
| repositorio | Repositório, periódico, base ou combinação de provedor e indexador. |
| url_original | Página oficial usada como origem da referência, handle, DOI ou ficha. |
| url_integral | URL da íntegra, da ficha ou do registro taxonômico em API. A leitura efetiva está em estado_leitura. |
| url_indice_adicional | Segundo registro bibliográfico ou página do editor associado à mesma obra. |
| data_acesso | Dia da consulta, no fuso de São Paulo, no formato AAAA-MM-DD. |
| direitos_uso | Licença ou nota de direitos recuperada, com seu alcance e eventuais limitações. |
| tipo_fonte | publicacao, taxonomia ou ficha_fitossanitaria. As duas últimas não integram o total de publicações. |
| acesso | Disponibilidade observada: integral_consultado, integral_localizado, ficha_consultada, somente_metadados_resumo ou metadados. |
| estado_leitura | catalogada, secoes_do_integral_analisadas ou ficha_conferida. A análise se refere às seções usadas na extração. |
| temas_indexados | Códigos A–F, separados por barra vertical. Assuntos da catalogação podem estar pendentes de extração. |

## fonte_culturas.csv

Relação muitos-para-muitos. Chave composta por fonte_id e cultura_id.

| Campo | Definição |
|---|---|
| fonte_id | ID persistente da referência; chave primária em fontes e estrangeira nas demais tabelas. |
| cultura_id | ID estável do recorte agrícola. Chave primária em culturas e estrangeira nas demais tabelas. |

## evidencias.csv

Uma afirmação, contraste ou medição por linha. Fonte, geografia e limites ficam na própria evidência.

| Campo | Definição |
|---|---|
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| fonte_id | ID persistente da referência; chave primária em fontes e estrangeira nas demais tabelas. |
| tema | A caracterização; B plantio/colheita; C rotação; D solo; E fitossanidade; F produtividade/resultado. |
| tipo_evidencia | Natureza da afirmação, descrita no vocabulário abaixo. |
| localizador | Página do PDF contada a partir de 1, página impressa quando especificada, tabela, figura, seção ou linha da ficha. |
| pais_iso2 | País do estudo, âmbito da ficha ou distribuição (ISO 3166-1 alfa-2); nulo quando a associação não tem recorte nacional. |
| regiao | Recorte geográfico original. Pode indicar município, região ou rede de ambientes. |
| condicoes | Ambiente, desenho, época, manejo e outras circunstâncias necessárias para interpretar o resultado. |
| material | Cultivar, grupo de ciclo ou genótipo quando explicitado. Em comparações da cana, o prefixo Antecessora identifica o material precedente. |
| achado | Síntese da afirmação ou significado da célula quantitativa. |
| metrica | Nome da grandeza medida ou do contraste. Não agregar variáveis de produtos diferentes. |
| valor | Número decimal de uma medida ou contraste comparável. Valores nulos não foram estimados. |
| unidade | Unidade explícita (por exemplo kg/ha, Mg/ha, t/ha ou %). 1 Mg/ha = 1 t/ha = 1.000 kg/ha. |
| comparador | Referência para o contraste ou identificação dos tratamentos comparáveis. |
| limitacoes | Incerteza, significância estatística, restrição de aplicação ou ressalva editorial. |
| status_validacao | conferida_na_fonte identifica achado aceito nesta revisão documental. |
| cultura_desfecho_id | Chave da cultura cujo produto foi medido em F. Em branco para outros temas. |
| rotacao_id | Chave primária da sequência em rotacoes. Em evidencias, vínculo opcional de um resultado à sequência inequívoca. |
| estudo_id | Agrupador analítico do ensaio ou levantamento. Pode aparecer em tratamentos, tabelas e fontes secundárias do mesmo experimento. |
| solo | Classe ou textura da fonte, quando estruturada. Condições complementares permanecem em condicoes. |
| regime_hidrico | Regime estruturado, como irrigado, sequeiro ou irrigado_por_inundacao. Nulo se não estruturado. |
| n_cobertura_kg_ha | Nitrogênio em cobertura do tratamento experimental em kg de N/ha. Zero significa testemunha sem N em cobertura. |

## evidencia_culturas.csv

Relação muitos-para-muitos. Chave composta por evidencia_id e cultura_id.

| Campo | Definição |
|---|---|
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| cultura_id | ID estável do recorte agrícola. Chave primária em culturas e estrangeira nas demais tabelas. |
| papel | desfecho, contexto_do_resultado ou relacionada. A orientação de pares agrícolas está em rotacoes. |

## calendarios.csv

Um evento, janela ou intervalo fenológico por linha. Fonte, material, região e limites são recuperados pela evidência.

| Campo | Definição |
|---|---|
| calendario_id | Chave primária do evento ou janela agrícola. |
| cultura_id | ID estável do recorte agrícola. Chave primária em culturas e estrangeira nas demais tabelas. |
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| evento | Tipo de janela: plantio, colheita, fase, corte, período experimental ou plantio modelado. |
| mes_inicio | Mês inicial (1–12) na precisão expressa no texto. |
| mes_fim | Mês final (1–12); quando inferior ao mês inicial, a janela atravessa o fim do ano. |
| precisao_janela | Qualificadores da janela ou evento, incluindo início, meados, fim ou condições fenológicas. |
| marco_inicial | Origem temporal da duração. inicio_nao_especificado conserva a ausência desse detalhe. |
| marco_final | Estádio final da duração, como antese, maturação ou colheita. |
| duracao_min | Menor duração na fonte. Para ponto único ou média pontual, igual à máxima. |
| duracao_max | Maior duração, na mesma unidade. |
| unidade_duracao | dia ou mês, preservando a unidade original. |
| dia_inicio | Dia civil inicial quando explicitado pela fonte e estruturado. |
| dia_fim | Dia civil final sob o mesmo critério. |

## rotacoes.csv

Um par ordenado, com consorte e cobertura intercalar opcionais. A natureza da sequência está em relacao e tipo_evidencia.

| Campo | Definição |
|---|---|
| rotacao_id | Chave primária da sequência em rotacoes. Em evidencias, vínculo opcional de um resultado à sequência inequívoca. |
| antecessora_id | Chave da cultura principal anterior ou da cobertura anterior. |
| sucessora_id | Chave da cultura que vem depois. |
| consorte_antecessora_id | Chave opcional da cultura cultivada simultaneamente com a antecessora. |
| cobertura_intercalar_id | Chave opcional da cobertura entre a antecessora comercial e a sucessora. |
| relacao | Tipo do vínculo: distingue, por exemplo, pastagem prévia, cobertura potencial e sucessão experimental. |
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| beneficio_documentado | Benefício qualitativo atribuído pela fonte, quando extraído separadamente; consultar também resultados e comparadores. |
| restricao_documentada | Restrição agronômica registrada para a sequência. Consultar ainda condições e limitações da evidência. |

## pragas_doencas.csv

Uma relação documental, uma ficha preventiva ou uma distribuição por linha. Para hospedeiros adicionais, consultar registros do mesmo organismo, preservando a categoria e a fonte de cada par.

| Campo | Definição |
|---|---|
| registro_id | Chave primária do registro fitossanitário. |
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| cultura_id | ID estável do recorte agrícola. Chave primária em culturas e estrangeira nas demais tabelas. |
| organismo | Nome científico conforme a fonte, inclusive nomenclatura histórica. |
| nome_problema | Denominação do problema ou do organismo para exibição. |
| categoria_hospedeiro | Classificação literal da EPPO, como Host, Major host ou Experimental. |
| sinais_sintomas | Sinais ou sintomas descritos na fonte. Não confirmam diagnóstico na propriedade. |
| prevencao_monitoramento | Prática preventiva ou de monitoramento extraída da fonte. |
| distribuicao_documentada | Estado territorial do organismo, separado da associação com a cultura. |
| url_organismo | Link para a ficha de identificação do organismo na EPPO quando recuperado. |
| tipo_registro | associacao_hospedeiro, distribuicao_do_organismo ou ficha_tecnica. |
| condicao_associada | Condição ambiental ou de manejo descrita para o problema. Não é probabilidade estimada. |

## manejo_solo.csv

Uma prática ou comparação por evidência. As culturas ligadas estão em evidencia_culturas.

| Campo | Definição |
|---|---|
| manejo_id | Chave primária do registro de manejo ou comparação de solos. |
| evidencia_id | ID estável do achado. Chave primária em evidencias e estrangeira nas tabelas temáticas e de associação. |
| pratica | Prática de manejo ou tipo de comparação estudada. |
| propriedade_solo | Propriedade física, química ou biológica abordada. |

## Contagens de cobertura

A contagem de publicações analisadas exige ao menos uma extração da obra ligada à cultura. Fichas taxonômicas e fitossanitárias têm coluna própria. Somente achados conferidos foram exportados; por isso as duas contagens de extração e revisão coincidem. A–E contabilizam o tema do achado. F conta apenas a cultura do desfecho. Uma evidência multicultura pode aparecer em várias linhas da matriz.

O relatório é um retrato desta edição. Para atualizações, recalcular por IDs distintos respeitando tipo_fonte e papel da cultura. A fila em manifesto.json usa os mesmos IDs de fontes.csv.


## Campos acrescentados em v0.2.0

`evidencias.csv` mantém `status_validacao` por compatibilidade. `status_conferencia_documental` registra a conferência do trecho/arquivo; `status_validacao_agronomica` registra se a interpretação e transferibilidade passaram por validação especializada; `justificativa_validacao_agronomica` explica o limite. Nesta edição, `requer_revisao_especializada` não significa erro: sinaliza que a base não substitui a validação por agrônomo no contexto local.

`historico_v0.1_v0.2.csv` é append-only e documenta inclusões e preenchimentos de campos v0.1 antes nulos. Nenhum identificador ou registro v0.1 foi removido.


## v0.3.0

`evidencias.suficiencia_uso_computacional`: suficiente_para_exibir, evidencia_condicionada, evidencia_insuficiente ou evidencia_conflitante. `motivo_suficiencia` registra a justificativa. A classificação é por registro, não equivale a uma recomendação nem validação agronômica. `linho` é cultura auxiliar (*Linum usitatissimum* L.), sem modelo AquaCrop presumido.


## v0.4.0 — integração auditada

`auditoria_individual_15.csv` registra a decisão documental por evidência; `quarentena/` conserva entradas não incorporadas. `fontes_revisadas.csv` do lote foi aplicado como atualização de estado nas fontes existentes; não criou novas fontes. `historico_v0.3_v0.4.csv` registra mudanças por campo e inclusão. `estudo_id` preserva a origem comum, inclusive o ensaio de Basso et al. (1998) reproduzido por EMB-215790. A auditoria documental não equivale a validação agronômica.
